# Song-Popularity-Predictor
SMAI 2017 Project

Git-hub link : https://github.com/adarsh1001/Song-Popularity-Predictor

Team Members :
- Bakhtiyar Syed (201525094)
- Aakash KT (20161202)
- Saurav Malani (201502047)
- Adarsh Pal Singh (20161225)